package com.example;

public @interface EnableJpaRepositories {

}
